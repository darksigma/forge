module.exports = {
	firebaseUrl: "https://forge-app2.firebaseio.com/"
}
