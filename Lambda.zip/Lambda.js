// dependencies
var AWS = require('aws-sdk');
 
exports.handler = function(event, context) {
	console.log("hello lambda")
};